namespace $rootnamespace$
{
    using Nancy;

    public class $safeitemname$ : NancyModule
    {
        public $safeitemname$()
        {
        }
    }
}